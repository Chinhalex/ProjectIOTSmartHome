package com.example.smarthomeapp.evenbus;

public class MyUpdateCartEvent {
}
